# Assignment 2
1. Run the client with "sudo python3 client.py"
2. Enter the destination IP (e.g. 127.0.0.1)
3. Enter a message (e.g. Hello World)
4. Open another terminal and run "sudo python3 server.py"
5. Sucess gg wp ez win